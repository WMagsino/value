#include <stdio.h>

int main() {
    float money, totalCost;
    int orange, apple, banana;
    
    printf("How much money do you have? ");
    scanf("%f", &money);
    printf("Enter the number of orange you want to buy: ");
    scanf("%d", &orange);
    printf("Enter the number of apple you want to buy: ");
    scanf("%d", &apple);
    printf("Enter the number of banana you want to buy: ");
    scanf("%d", &banana);

    totalCost = (orange + apple + banana) * 15;

    // Calculate the change
    float change = money - totalCost;
    printf("You bought %d orange, %d apple, and %d banana.\n", orange, apple, banana);
    printf("Total cost: %.2f pesos\n", totalCost);
    printf("Your change: %.2f pesos\n", change);

    return 0;
}
